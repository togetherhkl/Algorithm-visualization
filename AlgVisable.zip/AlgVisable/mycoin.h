﻿#ifndef MYCOIN_H
#define MYCOIN_H
#include <QWidget>
#include<QPushButton>
class mycoin : public QPushButton
{
    Q_OBJECT
public:
    //explicit mycoin(QWidget *parent = nullptr);
    mycoin(QString btnImg);
    int posx;
    int posy;
    int graphposx;
    int graphposy;

    int min=1;
    int max=8;
    void movesite(int newx,int newy);
signals:
};
#endif // MYCOIN_H
