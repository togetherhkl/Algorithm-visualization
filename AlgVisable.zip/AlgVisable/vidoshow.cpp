﻿#include "vidoshow.h"
#include "ui_vidoshow.h"
#include <QMediaPlayer>
#include<QFileDialog>
#include<QVideoWidget>
#include<QString>
#include<QDebug>
#include<QPixmap>
#include"mainwindow.h"
#include<QPainter>
#pragma execution_character_set("utf-8")

extern QString vidopathname;//应用主窗体的视频路径
QMediaPlayer* player=new QMediaPlayer();   //播放器
vidoshow::vidoshow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::vidoshow)
{
    ui->setupUi(this);
    ui->label->setVisible(false);
    qDebug()<<"视频路经："<<vidopathname;
    QVideoWidget* widget=new QVideoWidget(this);   //视频播放控件
    widget->resize(ui->label->size());
    widget->setGeometry(50,100,widget->width(),widget->height());//设置位置
    player->setVideoOutput(widget);
    QString vidopath=vidopathname;
    player->setMedia(QUrl::fromLocalFile(vidopath));
    player->play();
    connect(ui->pushButton,&QPushButton::clicked,this,[=](){
        player->pause();
    });
    connect(ui->pushButton_2,&QPushButton::clicked,this,[=](){
        player->play();
    });
    QPixmap pix;
    pix.load(":/res/暂停.png");//暂停图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton->setIcon(QIcon(pix));
    ui->pushButton->setIconSize(QSize(40, 40));
    ui->pushButton->setFlat(true);//边框是否突起
    pix.load(":/res/播放.png");//播放图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_2->setIcon(QIcon(pix));
    ui->pushButton_2->setIconSize(QSize(40, 40));
    ui->pushButton_2->setFlat(true);//边框是否突起
    pix.load(":/res/返回1.png");//返回图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_3->setIcon(QIcon(pix));
    ui->pushButton_3->setIconSize(QSize(40, 40));
    ui->pushButton_3->setFlat(true);//边框是否突起
    connect(ui->pushButton_3,&QPushButton::clicked,this,[=](){
        emit backtomain();
        player->pause();
        this->close();
    });
    this->setWindowTitle(QString("视频演示"));//设置title
    this->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowCloseButtonHint);//去掉问好
    this->setWindowIcon(QPixmap(":/res/视频.png"));//设置图标
}
vidoshow::~vidoshow()
{
    delete ui;
}
void vidoshow::paintEvent(QPaintEvent *)
{
    //设置背景
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/res/主页背景11.jpeg");
    painter.drawPixmap(0,0,this->width(),this->height(),pix);
}
