﻿#include "pictureshow.h"
#include "ui_pictureshow.h"
#include<QPainter>
#include<QWheelEvent>
#include<QMouseEvent>
#include<QPixmap>
#include<QIcon>
#pragma execution_character_set("utf-8")
extern QString picname;//引用登录界面的文字解答的图片路径
PictureShow::PictureShow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PictureShow)
{
    ui->setupUi(this);
    this->setWindowTitle("文字解答图片形式");
    this->setWindowIcon(QPixmap(":/res/照片.png"));
    QPixmap pix;
    pix.load(picname);
    w=pix.width();//先初始化长宽
    h=pix.height();
}

PictureShow::~PictureShow()
{
    delete ui;
}
void PictureShow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(picname);
    painter.drawPixmap(x,y,w,h,pix);
}
void PictureShow::wheelEvent(QWheelEvent *event)
{
    if (event->delta()>0) {
        w=w*0.8;
        h=h*0.8;
        this->update();//上滑,缩小
         } else { //下滑,放大
        w=w*1.2;
        h=h*1.2;
        this->update();
         }
         event->accept();
}
void PictureShow::mouseMoveEvent(QMouseEvent *event)
{
    Qt::MouseButtons btns=event->buttons();
    if(Qt::LeftButton==(btns &Qt::LeftButton))//鼠标左键按下移动事件
    {
        x=event->x()-temp.x();
        y=event->y()-temp.y();
        this->update();
    }
}
void PictureShow::mousePressEvent(QMouseEvent *ev)
{
    if(ev->button()==Qt::LeftButton)
        temp=ev->pos();
}

