﻿#ifndef MYALGTITLEDIALOG_H
#define MYALGTITLEDIALOG_H
#include <QDialog>
namespace Ui {
class myAlgTitleDialog;
}
class myAlgTitleDialog : public QDialog
{
    Q_OBJECT
public:
    explicit myAlgTitleDialog(QWidget *parent = nullptr);
    ~myAlgTitleDialog();
    void creationcoin2(int n);//画出直角三角形金币
    void deletecoin2();//删除所有金币
    void Odd_Transform(int n);//奇数斜线金币的变换
    void Even_Transform(int n);//偶数斜线金币的变换
    void Two_Transform(int n);//两条斜线金币的变换
    void CreatMoveCoin(int x,int y);//把被移动的金币的原先位置变成灰色
    void paintEvent(QPaintEvent *);//绘制背景图
    void SceneConfig();//场景配置函数
private:
    Ui::myAlgTitleDialog *ui;
signals:
    void backmainsecen();//返回到主页的信号
};
#endif // MYALGTITLEDIALOG_H
