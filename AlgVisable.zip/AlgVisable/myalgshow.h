﻿#ifndef MYALGSHOW_H
#define MYALGSHOW_H

#include <QWidget>
#include<QDialog>

//class myalgshow : public QWidget
class myalgshow : public QDialog
{
    Q_OBJECT
public:
    //explicit myalgshow(QWidget *parent = nullptr);
    myalgshow(int n);

    void deletecoin();//清楚有金币
    void createcoin(int n);//画出金币的样子
signals:

};

#endif // MYALGSHOW_H
