﻿#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H
#include <QDialog>
#include<encdec.h>
namespace Ui {
class loginDialog;
}
class loginDialog : public QDialog
{
    Q_OBJECT
public:
    explicit loginDialog(QWidget *parent = nullptr);
    ~loginDialog();
    void LogConfig();
    void paintEvent(QPaintEvent *);//绘制背景图
private slots:

signals:
    void sendData(QString);//把账号信息发送出去
private:
    Ui::loginDialog *ui;

};
#endif // LOGINDIALOG_H
