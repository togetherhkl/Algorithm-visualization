﻿#include "myalgshow.h"
#pragma execution_character_set("utf-8")
#include"mycoin.h"
#include<QDebug>
#include<QList>
#include<QTimer>



//myalgshow::myalgshow(QWidget *parent) : QWidget(parent)
//{

//}
myalgshow::myalgshow(int n)
{

    this->setFixedSize(1000,1000);
    this->setWindowIcon(QPixmap(":/res/Coin0001.png"));
    this->setWindowTitle("变换演示");
    //qDebug()<<"Geometry为"<<this->geometry();//查看Geometry
    this->setGeometry(QRect(770,450,1000,800));//设置在窗体中的位置
    this->setWindowFlags(Qt::Dialog);//去掉最大化最小化
    this->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowCloseButtonHint);//去掉问好

    createcoin(n);//创建金币的按钮
    if(n%2!=0&&n>1)
    {
    int btncount=this->children().count();//输出该窗体的所有控件
    int starmoveset=n/2;//计算开始移动的行数
    qDebug()<<starmoveset;//查看开始移动的行数
    int movecount=0;

    for(int i=0;i<btncount;i++)//遍历该窗体的所有控件
    {
         if(this->children().at(i)->inherits("mycoin"))//判断控件的类型
         {
         mycoin *bt=(mycoin *)(this->children().at(i));
         //qDebug()<<bt->posx<<" "<<bt->posy;
         if(bt->posx>starmoveset)
         {
             movecount=bt->posx-starmoveset-1;
             if(bt->posy<=movecount)//移动右边
             {
                 bt->movesite(bt->graphposx+movecount*50,bt->graphposy-movecount*100);
             }
             if(bt->posy>=(2*bt->posx-movecount))//移动左边
             {
                 bt->movesite(bt->graphposx-movecount*50,bt->graphposy-movecount*100);
             }

         }
      }
    }
    }
    if(n%2==0&&n>2)
    {
        int btncount=this->children().count();//输出该窗体的所有控件
        int starmoveset=n/2;//第几行开会时移动金币
        qDebug()<<starmoveset;//显示
        int movecount=1;//移动金币的数量
        for(int i=0;i<btncount;i++)//遍历该窗体的所有控件
        {
             if(this->children().at(i)->inherits("mycoin"))//判断控件的类型
             {
             mycoin *bt=(mycoin *)(this->children().at(i));
             //qDebug()<<bt->posx<<" "<<bt->posy;
             if(bt->posx>starmoveset)
             {
                 movecount=bt->posx-starmoveset;//更新移动的数量
                 if(bt->posy<=movecount)//移动左边
                 {
                     bt->movesite(bt->graphposx+n*50,bt->graphposy-(2*(bt->posx-starmoveset)-1)*50);
                     //注意y轴上的偏移量，根据规律就，y轴每行是以1，3，5...*50的倍数开始偏移
                     //是一个等差数列
                 }
                 if(bt->posy>(2*bt->posx-movecount))//移动右边
                 {
                     bt->movesite(bt->graphposx-n*50,bt->graphposy-(2*(bt->posx-starmoveset)-1)*50);
                 }

             }
          }
        }
        //时隔4秒把当中的所有金币给删除
       deletecoin();//删除所有金币
       //重新画出金币
       QTimer::singleShot(5000,this,[=](){
           createcoin(n);
       });
       QTimer::singleShot(6000,this,[=](){
           //第二种移动的方法
           int btncount=this->children().count();//输出该窗体的所有控件
           int starmoveset=n/2;//第几行开会时移动金币
           qDebug()<<starmoveset;//显示
           int movecount=1;//移动金币的数量
           for(int i=0;i<btncount;i++)//遍历该窗体的所有控件
           {
                if(this->children().at(i)->inherits("mycoin"))//判断控件的类型
                {
                mycoin *bt=(mycoin *)(this->children().at(i));
                //qDebug()<<bt->posx<<" "<<bt->posy;
                if(bt->posx>starmoveset)
                {
                    movecount=bt->posx-starmoveset;//更新移动的数量
                    if(bt->posy>(2*bt->posx-movecount-1))//移动右边
                    {
                        bt->movesite(bt->graphposx-n*50,bt->graphposy-(2*(bt->posx-starmoveset)-1)*50);
                    }
                    if(bt->posy<=movecount-1)//移动左边
                    {
                        bt->movesite(bt->graphposx+n*50,bt->graphposy-(2*(bt->posx-starmoveset)-1)*50);
                        //注意y轴上的偏移量，根据规律就，y轴每行是以1，3，5...*50的倍数开始偏移
                        //是一个等差数列
                    }


                }
             }
           }
       });

    }
    if(n==2)
    {
        createcoin(n);
        int coincount=this->children().count();
        for(int i=0;i<coincount;i++)
        {
            if(this->children().at(i)->inherits("mycoin"));
            {
                mycoin *bt=(mycoin *)(this->children().at(i));
                if((bt->posx==2)&&(bt->posy==1))
                {
                    bt->movesite(bt->graphposx+100,bt->graphposy-50);
                }
            }
        }
        deletecoin();
        QTimer::singleShot(5000,this,[=](){
            createcoin(n);
        });
        QTimer::singleShot(7000,this,[=](){
            int coincount=this->children().count();
            for(int i=0;i<coincount;i++)
            {
                if(this->children().at(i)->inherits("mycoin"));
                {
                    mycoin *bt=(mycoin *)(this->children().at(i));
                    if((bt->posx==2)&&(bt->posy==3))
                    {
                        bt->movesite(bt->graphposx-100,bt->graphposy-50);
                    }
                }
            }
        });
        QTimer::singleShot(8000,this,[=](){
            deletecoin();
        });
        QTimer::singleShot(13000,this,[=](){
            createcoin(n);
        });
        QTimer::singleShot(15000,this,[=](){

            int coincount=this->children().count();
            for(int i=0;i<coincount;i++)//访问所有控件
            {
                //判断是否为自己定义的控件
                if(this->children().at(i)->inherits("mycoin"));
                {
                    mycoin *bt=(mycoin *)(this->children().at(i));
                    if((bt->posx==2)&&(bt->posy==2))
                    {
                        bt->movesite(bt->graphposx,bt->graphposy+50);
                    }
                }
            }
        });

    }
    this->exec();//必须关闭窗体才可以退出
}
void myalgshow::createcoin(int n)
{
    //mycoin *coin=new mycoin(":/res/Coin0001.png");
    //qDebug()<<coin->width()<<" "<<coin->height();//查看控件的大小
    //画出金币
    int mid=this->width()/2;
    int k=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<(2*i-1);j++)
        {
            mycoin*coin=new mycoin(":/res/Coin0001.png");
            coin->setParent(this);
            coin->posx=i;
            coin->posy=j+1;
            coin->move(mid-k+j*50,100+i*50);
            coin->graphposx=mid-k+j*50;
            coin->graphposy=100+i*50;
            coin->show();
        }
        k+=50;
    }
}
void myalgshow::deletecoin()
{
    //时隔4秒把当中的所有金币给删除掉
    QTimer::singleShot(4000,this,[=](){
        while (this->children().count()>=1) {
            for(int i=0;i<this->children().count();i++)
            {
            if(this->children().at(i)->inherits("mycoin"))//判断控件的类型
            {
                 delete this->children().at(i);
            }
            }

        }
    });
}

