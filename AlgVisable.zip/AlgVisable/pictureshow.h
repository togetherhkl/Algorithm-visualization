﻿#ifndef PICTURESHOW_H
#define PICTURESHOW_H
#include <QWidget>
namespace Ui {
class PictureShow;
}
class PictureShow : public QWidget
{
    Q_OBJECT
public:
    explicit PictureShow(QWidget *parent = nullptr);
    ~PictureShow();
    void paintEvent(QPaintEvent *);//绘制背景图
    void wheelEvent(QWheelEvent* event);//重写鼠标滑轮事件
    void mouseMoveEvent(QMouseEvent *event);
   // void keyPressEvent(QKeyEvent *event);
    void mousePressEvent(QMouseEvent *ev);
private:
    Ui::PictureShow *ui;
    int w=800;
    int h=1000;
    int x=200;
    int y=0;
    QPoint temp;
};
#endif // PICTURESHOW_H
