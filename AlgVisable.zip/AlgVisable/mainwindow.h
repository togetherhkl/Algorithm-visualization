﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *);//绘制背景图
private:
    Ui::MainWindow *ui;
    void mainwindowconfig();//主页配置
private slots:
signals:
    void backtolog();//返回到登录界面信号
};
#endif // MAINWINDOW_H
