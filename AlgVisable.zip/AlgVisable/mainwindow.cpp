﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"logindialog.h"
#include<QString>
#include<QSqlQuery>
#include<QDebug>
#include<QPainter>
#include<QPalette>//给widget设置背景图
#include"myalgtitledialog.h"
#include<QFile>
#include"pictureshow.h"
#include<QMessageBox>
#include<QFileDialog>
#include<QDateTime>
#include"vidoshow.h"
#pragma execution_character_set("utf-8")
extern QString glbaccount;//引用登录界面的变量
QString picname="";//定义一个全局变量，存文字解答的图片路径，供图片展示窗体使用
QString vidopathname="";//定义一个全局变量，存视频解答的图片路径，供频频播放窗体使用
int flage=1;//1为提供文字答案，0为提供代码答案
vidoshow *vido;//在视频监听下能够捕获，并实例化
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    mainwindowconfig();
    //监听combobox选择的变化
    connect(ui->comboBox,&QComboBox::currentTextChanged,this,[=](){
        ui->widget->setVisible(true);
        ui->widget_2->setVisible(false);
        ui->listWidget->setVisible(true);
        ui->textBrowser->setVisible(false);
        ui->listWidget->clear();
        ui->pushButton->setEnabled(false);
        ui->pushButton_2->setEnabled(false);
        ui->pushButton_3->setEnabled(false);
        ui->pushButton_4->setEnabled(false);
        ui->textEdit->setVisible(false);
        ui->pushButton_11->setVisible(false);
        ui->pushButton_12->setVisible(false);
        QString tikumc=ui->comboBox->currentText();//获取题库的名称
        QString str=QString("select 题库代号 from 题库表 where 题库名称='%1'").arg(tikumc);//获取题库代号
        qDebug()<<str;//查看sql语句是否正确
        QSqlQuery query1;
        query1.exec(str);//查询
        query1.next();//指向第一条数据
        QString tikudh=query1.value(0).toString();//获取题库代号
        str=QString("select 题号,题目名称 from 题目表 where 题库来源='%1'").arg(tikudh);
        query1.exec(str);
        qDebug()<<str;
        while(query1.next())
        {
            QString temp=QString("%1.%2").arg(query1.value(0).toString()).arg(query1.value(1).toString());
            ui->listWidget->addItem(temp);
        }
    });
    //监听listview的点击的变化
    connect(ui->listWidget,&QListWidget::currentTextChanged,this,[=](){
        if(ui->listWidget->currentItem()!=NULL)
        {
            ui->pushButton->setEnabled(false);
            ui->pushButton_2->setEnabled(false);
            ui->pushButton_3->setEnabled(false);
            ui->pushButton->setStyleSheet("QPushButton{background-color:rgb(255,255,255);}");//更改颜色
            ui->pushButton_2->setStyleSheet("QPushButton{background-color:rgb(255,255,255);}");//更改颜色
            ui->pushButton_3->setStyleSheet("QPushButton{background-color:rgb(255,255,255);}");//更改颜色
            ui->pushButton_4->setEnabled(true);//提供解答按钮开启
            ui->pushButton_4->setStyleSheet("QPushButton{background-color:orange;}");
            QString timunr=ui->listWidget->currentItem()->text();//获取题目内容
            qDebug()<<timunr;//查看题目内容是否获取成功
            int x=timunr.indexOf(".");//查看"."的位置
            QString temp=timunr.mid(0,x);//截取获取题目代号
            qDebug()<<temp;
            QSqlQuery query2;
            QString str=QString("select 解题方式 from 题目解答表 where 题号=%1").arg(temp);
            query2.exec(str);
            while (query2.next()) {
                if(query2.value(0).toString().compare("文字解答")==0)
                {
                    ui->pushButton_2->setEnabled(true);
                    ui->pushButton_2->setStyleSheet("QPushButton{background-color:orange;}");//更改颜色
                }
                else if(query2.value(0).toString().compare("代码解答")==0)
                {
                    ui->pushButton->setEnabled(true);
                    ui->pushButton->setStyleSheet("QPushButton{background-color:orange;}");//更改颜色
                }
                else if(query2.value(0).toString().compare("视频解答")==0)
                {
                    ui->pushButton_3->setEnabled(true);
                    ui->pushButton_3->setStyleSheet("QPushButton{background-color:orange;}");//更改颜色
                }
            }
        }
    });
    connect(ui->pushButton_5,&QPushButton::clicked,this,[=](){//监听关闭按钮
        ui->comboBox->setCurrentIndex(0);
        ui->widget->setVisible(false);
        ui->pushButton_7->setVisible(false);
        ui->widget_2->setVisible(false);
    });
    connect(ui->pushButton_6,&QPushButton::clicked,this,[=](){//监听注销按钮
        loginDialog *log=new loginDialog();
        log->show();
        this->close();
    });
    connect(ui->listWidget,&QListWidget::itemDoubleClicked,this,[=](){//监听listwidget双击操作
        QString timunr=ui->listWidget->currentItem()->text();//获取题目内容
        qDebug()<<timunr;//查看题目内容是否获取成功
        int x=timunr.indexOf(".");//查看"."的位置
        QString temp=timunr.mid(0,x);//截取获取题目代号
        QSqlQuery query2;
        QString str=QString("select 题目内容 from 题目表 where 题号='%1'").arg(temp);
        qDebug()<<str;
        query2.exec(str);
        query2.next();
        ui->textBrowser->setText(query2.value(0).toString());
        ui->textBrowser->setVisible(true);
        ui->listWidget->setVisible(false);
        ui->pushButton_7->setVisible(true);
    });
    connect(ui->pushButton_7,&QPushButton::clicked,this,[=](){//监听返回按钮
        ui->textBrowser->setVisible(false);
        ui->listWidget->setVisible(true);
        ui->pushButton_7->setVisible(false);
        ui->pushButton_11->setVisible(false);
        ui->pushButton_12->setVisible(false);
    });
    myAlgTitleDialog *myque=new myAlgTitleDialog();
    connect(ui->pushButton_3,&QPushButton::clicked,this,[=](){//监听视频按钮
        QString timunr=ui->listWidget->currentItem()->text();//获取题目内容
        qDebug()<<timunr;//查看题目内容是否获取成功
        int x=timunr.indexOf(".");//查看"."的位置
        QString temp=timunr.mid(0,x);//截取获取题目代号
        QSqlQuery query3;
        QString str=QString("select 解题内容 from 题目解答表 where 题号='%1' and 解题方式='视频解答'").arg(temp);
        qDebug()<<str;//查看sql语句是否正确
        if(temp.compare("00010001")==0)//特殊情况，"算法谜题：直角三角形变正方形"
        {
            myque->show();
            this->hide();
        }
        else
        {
            query3.exec(str);
            query3.next();
            vidopathname=query3.value(0).toString();
            vido=new vidoshow();
            vido->show();
            this->hide();
            connect(vido,&vidoshow::backtomain,this,[=](){//监听视频播放放回按钮
                this->show();
            });
        }
    });
    connect(myque,&myAlgTitleDialog::backmainsecen,this,[=](){//算法谜题返回的信号
        this->show();
    });
    connect(ui->pushButton_2,&QPushButton::clicked,this,[=](){//监听文字解答按钮
        QString timunr=ui->listWidget->currentItem()->text();//获取题目内容
        qDebug()<<timunr;//查看题目内容是否获取成功
        int x=timunr.indexOf(".");//查看"."的位置
        QString temp=timunr.mid(0,x);//截取获取题目代号
        QSqlQuery query4;
        QString str=QString("select 解题内容 from 题目解答表 where 题号='%1' and 解题方式='文字解答'").arg(temp);
        query4.exec(str);
        query4.next();//遗留问题，如果该题的文字解答有多条解答数据的话，还要设计上下条的翻阅功能，这里的前提条件是一条
        QString filename=query4.value(0).toString();
        picname=filename;//把路径复制给全局变量
        if(QFile::exists(filename))//如果文字解答存的是图片
        {
            PictureShow *img=new PictureShow();
            img->show();
        }
        else//如果存的是文字
        {
            ui->textBrowser->clear();
            ui->textBrowser->setText(filename);
            ui->textBrowser->setVisible(true);//打开文字显示
            ui->pushButton_7->setVisible(true);//打开返回按钮
            ui->listWidget->setVisible(false);//关闭题目显示
        }
    });
    connect(ui->pushButton,&QPushButton::clicked,this,[=](){//监听代码解答按钮
        QString timunr=ui->listWidget->currentItem()->text();//获取题目内容
        qDebug()<<timunr;//查看题目内容是否获取成功
        int x=timunr.indexOf(".");//查看"."的位置
        QString temp=timunr.mid(0,x);//截取获取题目代号
        QSqlQuery query4;
        QString str=QString("select 解题内容 from 题目解答表 where 题号='%1' and 解题方式='代码解答'").arg(temp);
        query4.exec(str);
        query4.next();//遗留问题，如果该题的文字解答有多条解答数据的话，还要设计上下条的翻阅功能，这里的前提条件是一条
        QString codecontent=query4.value(0).toString();
        ui->textBrowser->clear();
        ui->textBrowser->setText(codecontent);
        ui->textBrowser->setVisible(true);//打开文字显示
        ui->pushButton_7->setVisible(true);//打开返回按钮
        ui->listWidget->setVisible(false);//关闭题目显示
    });
    connect(ui->pushButton_4,&QPushButton::clicked,this,[=](){//监听提供想法按钮
        if(ui->widget_2->isVisible())
        {
            ui->widget_2->setVisible(false);
        }
        else
        {
            ui->widget_2->setVisible(true);
        }
        ui->textEdit->setVisible(false);
        ui->pushButton_11->setVisible(false);
        ui->pushButton_12->setVisible(false);
    });
    connect(ui->pushButton_8,&QPushButton::clicked,this,[=](){//监听提供代码解答按钮
        flage=0;//表示提供代码答案
        ui->textEdit->setVisible(true);
        ui->pushButton_11->setVisible(true);
        QMessageBox::about(this,"提示","请在编辑框中输入代码并点击提交,单击“提供想法”可取消");
    });
    connect(ui->pushButton_9,&QPushButton::clicked,this,[=](){//监听提供文字解答按钮
        flage=1;//表示提供文字解答
        ui->textEdit->setVisible(true);
        ui->pushButton_11->setVisible(true);//提交按钮
        ui->pushButton_12->setVisible(true);//图片文字按钮
        QMessageBox::about(this,"提示","请在编辑框中输入文字解答并点击提交,如果文字解答是图片"
                                     "形式，请选择图片，单击“提供想法”可取消");
    });
    connect(ui->pushButton_11,&QPushButton::clicked,this,[=](){//监听文字，代码的提交按钮
        if(ui->textEdit->document()->isEmpty())
        {
            QMessageBox::warning(this,"提示","请输入有效内容在提交");
            return;
        }
        QString timunr=ui->listWidget->currentItem()->text();//获取题目内容
        qDebug()<<timunr;//查看题目内容是否获取成功
        int x=timunr.indexOf(".");//查看"."的位置
        QString temp=timunr.mid(0,x);//截取获取题目代号
        QSqlQuery query4;
        if(flage==0)//提供代码解答
        {
            QString sql=QString("insert into 题目解答表 values('%1','%2','代码解答','%3')").arg(temp)
                    .arg(glbaccount).arg(ui->textEdit->toPlainText());
            qDebug()<<sql;//显示语句查看sql是否正确
            query4.exec(sql);
            QMessageBox::about(this,"提示","代码解答提交成功!");
            ui->textEdit->setVisible(false);//关闭提交按钮
            ui->pushButton_11->setVisible(false);//关闭编辑框
            ui->pushButton_12->setVisible(true);//图片文字按钮
            sql=QString("select 贡献值 from 用户表 where 账号='%1'").arg(glbaccount);
            query4.exec(sql);
            query4.next();
            int contribut=query4.value(0).toInt();
            contribut++;//贡献值+1
            sql=QString("update 用户表 set 贡献值=%1 where 账号='%2'").arg(contribut).arg(glbaccount);
            query4.exec(sql);
        }
        if(flage==1)//提供文字解答
        {
            QString sql=QString("insert into 题目解答表 values('%1','%2','文字解答','%3')").arg(temp)
                    .arg(glbaccount).arg(ui->textEdit->toPlainText());
            qDebug()<<sql;//显示语句查看sql是否正确
            query4.exec(sql);
            QMessageBox::about(this,"提示","文字解答提交成功!");
            ui->textEdit->setVisible(false);//关闭提交按钮
            ui->pushButton_11->setVisible(false);//关闭编辑框
            sql=QString("select 贡献值 from 用户表 where 账号='%1'").arg(glbaccount);
            query4.exec(sql);
            query4.next();
            int contribut=query4.value(0).toInt();
            contribut++;//贡献值+1
            sql=QString("update 用户表 set 贡献值=%1 where 账号='%2'").arg(contribut).arg(glbaccount);
            query4.exec(sql);
        }
    });
    connect(ui->pushButton_12,&QPushButton::clicked,this,[=](){//监听选择图片文字按钮
        QString picpath=QFileDialog::getOpenFileName(this,tr("选择图像"),"",tr("Images (*.png *.bmp *.jpg)"));
        if(picpath.isEmpty())
            return;
        else
        {
           QImage img;
            if(!(img.load(picpath))) //加载图像
           {
               QMessageBox::information(this, tr("打开图像失败"),tr("打开图像失败!"));
               return;
           }
        }
        QString timunr=ui->listWidget->currentItem()->text();//获取题目内容
        qDebug()<<timunr;//查看题目内容是否获取成功
        int x=timunr.indexOf(".");//查看"."的位置
        QString temp=timunr.mid(0,x);//截取获取题目代号
        QDateTime curDateTime=QDateTime::currentDateTime();
        QString time=curDateTime.toString("yyMMddhhmmss");//获取图片命名的时间
        QFileInfo fileInfo = QFileInfo(picpath);//获取图片后缀名
        QString houzhui=fileInfo.suffix();
        //拼凑图片的路径，账号+题号+时间+原图片后缀
        QString imgpath=QString("./literalans/%1%2%3.%4").arg(glbaccount).arg(temp).arg(time).arg(houzhui);
        QFile::copy(picpath,imgpath);//把图片复制到文件的相对路径之下
        QString sql=QString("insert into 题目解答表"
                            " values ('%1','%2','文字解答','%3')").arg(temp).arg(glbaccount).arg(imgpath);
        qDebug()<<sql;
        QSqlQuery query;
        query.exec(sql);
        sql=QString("select 贡献值 from 用户表 where 账号='%1'").arg(glbaccount);
        query.exec(sql);
        query.next();
        int contribut=query.value(0).toInt();
        contribut++;//贡献值+1
        sql=QString("update 用户表 set 贡献值=%1 where 账号='%2'").arg(contribut).arg(glbaccount);
        query.exec(sql);
        QMessageBox::about(this,"提示","文字解答图片提交成功!");
        ui->textEdit->setVisible(false);//关闭提交按钮
        ui->pushButton_11->setVisible(false);//关闭编辑框
        ui->pushButton_12->setVisible(false);
    });
    connect(ui->pushButton_10,&QPushButton::clicked,this,[=](){//监听提供视频解答按钮
        QString filename = QFileDialog::getOpenFileName(this,tr("选择视频文件"),".",
                                                        tr("视频格式(*.mov *.avi *.mp4 *.flv *.mkv)"));
        if(filename.isEmpty())
            return;
        QString timunr=ui->listWidget->currentItem()->text();//获取题目内容
        qDebug()<<timunr;//查看题目内容是否获取成功
        int x=timunr.indexOf(".");//查看"."的位置
        QString temp=timunr.mid(0,x);//截取获取题目代号
        QDateTime curDateTime=QDateTime::currentDateTime();
        QString time=curDateTime.toString("yyMMddhhmmss");//获取图片命名的时间
        QFileInfo fileInfo = QFileInfo(filename);//获取视频后缀名
        QString houzhui=fileInfo.suffix();
        //拼凑图片的路径，账号+题号+时间+原图片后缀
        QString vidopath=QString("./videans/%1%2%3.%4").arg(glbaccount).arg(temp).arg(time).arg(houzhui);
        QFile::copy(filename,vidopath);//把视频复制到文件的相对路径之下
        QString sql=QString("insert into 题目解答表"
                            " values ('%1','%2','视频解答','%3')").arg(temp).arg(glbaccount).arg(vidopath);
        qDebug()<<sql;
        QSqlQuery query;
        query.exec(sql);
        QMessageBox::about(this,"提示","视频解答解答提交成功!");
    });
}
MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::mainwindowconfig()
{
    ui->widget->setVisible(false);//把显示的窗口的widget先隐藏
    ui->widget_2->setVisible(false);//把提供想法的窗体也隐藏
    ui->pushButton_11->setVisible(false);//把提供想法的提交按钮隐藏
    ui->pushButton_12->setVisible(false);//把提供想法的图片文字按钮隐藏
    ui->textBrowser->setVisible(false);//把题目内容显示的框隐藏
    ui->textEdit->setVisible(false);//把提供解答的编辑款隐藏
    ui->pushButton->setEnabled(false);
    ui->pushButton_2->setEnabled(false);
    ui->pushButton_3->setEnabled(false);
    ui->pushButton_4->setEnabled(false);
    ui->pushButton_5->setStyleSheet("QPushButton{background-color:orange;}");
    ui->pushButton_7->setVisible(false);
    QSqlQuery query;
    QString count1=glbaccount;//获取登录界面传入的账户
    QString str=QString("select  *from 用户表 where 账号='%1'").arg(count1);//查询该用户的所有数据
    query.exec(str);
    query.next();//指向第一条数据
    QString userimagpath=query.value(5).toString();//获取用户的头像地址
    QPixmap pix1(userimagpath);//用label显示用户头像
    pix1=pix1.scaled(ui->label->width(),ui->label->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label->setPixmap(pix1);
    QString name=query.value(2).toString();//获取用户名
    ui->label_2->setText(name);
    QString account=query.value(0).toString();//获取账号
    ui->label_4->setText(account);
    QString phone=query.value(4).toString();//获取电话
    ui->label_5->setText(phone);
    QString contribution=query.value(6).toString();//获取贡献值
    ui->label_7->setText(contribution);
    //显示题库
    ui->comboBox->addItem("--请选择--");
    str=QString("select 题库名称 from 题库表 ");
    query.exec(str);
    while (query.next()) {
        ui->comboBox->addItem(query.value(0).toString());
    }
    //一些图标图片的优化
    this->setWindowTitle("主页");
    this->setWindowIcon(QPixmap(":/res/主页.png"));
    QPixmap pix(":/res/昵称.png");//昵称图标
    pix=pix.scaled(ui->label_8->width(),ui->label_8->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_8->setPixmap(pix);
    pix.load(":/res/账号.png");//账号图标
    pix=pix.scaled(ui->label_9->width(),ui->label_9->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_9->setPixmap(pix);
    pix.load(":/res/电话.png");//电话图标
    pix=pix.scaled(ui->label_10->width(),ui->label_10->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_10->setPixmap(pix);
    pix.load(":/res/贡献榜.png");//贡献图标
    pix=pix.scaled(ui->label_11->width(),ui->label_11->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_11->setPixmap(pix);
    pix.load(":/res/题库管理.png");//题库选择图标
    pix=pix.scaled(ui->label_12->width(),ui->label_12->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_12->setPixmap(pix);
    pix.load(":/res/代码生成.png");//代码解答图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton->setIcon(QIcon(pix));
    ui->pushButton->setIconSize(QSize(40, 40));
    ui->pushButton->setFlat(true);//边框是否突起
    pix.load(":/res/文字.png");//文字解答图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_2->setIcon(QIcon(pix));
    ui->pushButton_2->setIconSize(QSize(40, 40));
    ui->pushButton_2->setFlat(true);//边框是否突起
    pix.load(":/res/视频.png");//视频解答图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_3->setIcon(QIcon(pix));
    ui->pushButton_3->setIconSize(QSize(40, 40));
    ui->pushButton_3->setFlat(true);//边框是否突起
    pix.load(":/res/14想法.png");//提出贡献图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_4->setIcon(QIcon(pix));
    ui->pushButton_4->setIconSize(QSize(40, 40));
    ui->pushButton_4->setFlat(true);//边框是否突起
    pix.load(":/res/关闭.png");//关闭图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_5->setIcon(QIcon(pix));
    ui->pushButton_5->setIconSize(QSize(40, 40));
    ui->pushButton_5->setFlat(true);//边框是否突起
    pix.load(":/res/退出登录.png");//退出图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_6->setIcon(QIcon(pix));
    ui->pushButton_6->setIconSize(QSize(40, 40));
    ui->pushButton_6->setFlat(true);//边框是否突起
    ui->widget->setAutoFillBackground(true);//给widget加上背景图
    QPalette palette=ui->widget->palette();
    palette.setBrush(QPalette::Window,QBrush(QPixmap(":/res/主页背景10.jpeg").scaled(ui->widget->size(),Qt::IgnoreAspectRatio,Qt::SmoothTransformation))); // 使用平滑的缩放方式
    ui->widget->setPalette(palette);
    ui->widget_2->setAutoFillBackground(true);//给widget_2加上背景图
    palette=ui->widget_2->palette();
    palette.setBrush(QPalette::Window,QBrush(QPixmap(":/res/主页背景8.jpeg").scaled(ui->widget->size(),Qt::IgnoreAspectRatio,Qt::SmoothTransformation))); // 使用平滑的缩放方式
    ui->widget_2->setPalette(palette);
    QPalette palette1;//给listwidget加上背景图
    palette1.setBrush(QPalette::Base, QBrush(QPixmap(":/res/主页背景6.jpeg")));
    ui->listWidget->setPalette(palette1);
    palette1.setBrush(QPalette::Base, QBrush(QPixmap(":/res/主页背景11.jpeg")));//给textbrowser添加背景图
    ui->textBrowser->setPalette(palette1);
    pix.load(":/res/返回1.png");//返回图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_7->setIcon(QIcon(pix));
    ui->pushButton_7->setIconSize(QSize(40, 40));
    ui->pushButton_7->setFlat(true);//边框是否突起
    pix.load(":/res/代码生成.png");//提供代码解答图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_8->setIcon(QIcon(pix));
    ui->pushButton_8->setIconSize(QSize(40, 40));
    ui->pushButton_8->setFlat(true);//边框是否突起
    pix.load(":/res/文字.png");//提供文字解答图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_9->setIcon(QIcon(pix));
    ui->pushButton_9->setIconSize(QSize(40, 40));
    ui->pushButton_9->setFlat(true);//边框是否突起
    pix.load(":/res/视频.png");//提供视频解答图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_10->setIcon(QIcon(pix));
    ui->pushButton_10->setIconSize(QSize(40, 40));
    ui->pushButton_10->setFlat(true);//边框是否突起
    pix.load(":/res/提交.png");//提供文字，代码解答的提交按钮
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_11->setIcon(QIcon(pix));
    ui->pushButton_11->setIconSize(QSize(40, 40));
    ui->pushButton_11->setFlat(true);//边框是否突起
    pix.load(":/res/图片.png");//提供图片文字的按钮
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton_12->setIcon(QIcon(pix));
    ui->pushButton_12->setIconSize(QSize(40, 40));
    ui->pushButton_12->setFlat(true);//边框是否突起
}
void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/res/主页背景5.jpeg");
    painter.drawPixmap(245,0,this->width()-245,this->height(),pix);
    pix.load(":/res/主页背景8.jpeg");
    painter.drawPixmap(0,0,245,this->height(),pix);
}
