﻿#ifndef VIDOSHOW_H
#define VIDOSHOW_H
#include <QWidget>
namespace Ui {
class vidoshow;
}
class vidoshow : public QWidget
{
    Q_OBJECT
public:
    explicit vidoshow(QWidget *parent = nullptr);
    ~vidoshow();
    void paintEvent(QPaintEvent *);//绘制背景图
private:
    Ui::vidoshow *ui;
signals:
    void backtomain();//返回主页信号
};

#endif // VIDOSHOW_H
