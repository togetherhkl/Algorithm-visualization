﻿#include "myalgtitledialog.h"
#include "ui_myalgtitledialog.h"
#include"mycoin.h"
#include<QMessageBox>
#pragma execution_character_set("utf-8")
#include<math.h>
#include<QDebug>
#include"myalgshow.h"
#include<QTimer>
#include<QPainter>
#include<QTextToSpeech>//文字转语音
#include<QSound>//播放mov文件
#include <QMediaPlayer>//播放MP3文件
myAlgTitleDialog::myAlgTitleDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::myAlgTitleDialog)
{
    ui->setupUi(this);
    SceneConfig();//配置函数
    connect(ui->pushButton,&QPushButton::clicked,this,[=](){//监听返回主页按钮
        emit backmainsecen();//发出返回的信息
        this->close();//关闭窗体
    });
    connect(ui->pBtnStart,&QPushButton::clicked,this,[=](){//监听点击开始按钮

        if(ui->lEdtInputN->text()=="")//如果未输入条数
        {
            QTextToSpeech *ttp=new QTextToSpeech(this);
            ttp->say("请输入斜线的条数！");
            QMessageBox::about(this,"提示","请输入斜线的条数！");
            delete ttp;
            return;
        }

        int n=ui->lEdtInputN->text().toInt();//把斜线转化为int型的数据
        if(45*(2*n-1)>1000)
        {
            QTextToSpeech *ttp=new QTextToSpeech(this);
            ttp->say("数量最多的一层超过屏幕可显示的数量");
            QMessageBox::about(this,"提示","数量最多的一层超过屏幕可显示的数量");
            delete ttp;
            return;
        }
        if(n<=1)
        {
            QTextToSpeech *ttp=new QTextToSpeech(this);
            ttp->say("斜线的数目需大于1");
            QMessageBox::about(this,"提示","斜线的数目需大于1");
            delete ttp;
            return;
        }
        float coinum=ceil(n/2.0)*floor(n/2.0);//ceil向上取整，floor向下取整，求需要移动金币的数量
        QString coinumts=QString("%1").arg(coinum);//把移动的金币数量准换成字符串
        ui->labCoinNum->setText(coinumts);
        ui->labCoinNum->setVisible(true);
        //判断斜线数目，确定移动的种类
        if(n>2&&(n%2==0))
        {           
            ui->labSuqNum->setText("2");
        }
        if(n>1&&(n%2!=0))
        {
            ui->labSuqNum->setText("1");
        }
        if(n==2)
        {
            ui->labSuqNum->setText("3");
        }
        ui->labSuqNum->setVisible(true);
        //进入金币变化演示阶段
        //myalgshow *mashow=new myalgshow(n);
        //mashow->show();
        deletecoin2();
        //qDebug()<<this->children().count();
        creationcoin2(n);
        //qDebug()<<this->children().count();
        //设置语音播报器
        if(n%2!=0&&n>1)
        {
            QTextToSpeech *ttp=new QTextToSpeech(this);
            QString str=QString("你输入的斜线数为%1，是大于二的奇数，最少移动的金币数目为%2，可获得%3种不同正方形,请看演示")
                    .arg(n).arg(coinumts).arg("1");
            ttp->say(str);
            QTimer::singleShot(13000,this,[=](){//设置9秒，等语言播放完在移动
                delete ttp;//需要销毁才能在界面中重新绘制，不然会死机
                Odd_Transform(n);
            });
        }
        if(n%2==0&&n>2)
        {
            QTextToSpeech *ttp=new QTextToSpeech(this);
            QString str=QString("你输入的斜线数为%1，是大于二的偶数，最少移动的金币数目为%2，可获得%3种不同正方形,请看演示")
                    .arg(n).arg(coinumts).arg("2");
            ttp->say(str);
            QTimer::singleShot(12000,this,[=](){
                delete ttp;//需要销毁才能在界面中重新绘制，不然会死机
                Even_Transform(n);
            });
        }
        if(n==2)
        {
            QTextToSpeech *ttp=new QTextToSpeech(this);
            QString str=QString("你输入的斜线数为%1，最少移动的金币数目为%2，可获得%3种不同正方形,请看演示")
                    .arg(n).arg(coinumts).arg("3");
            ttp->say(str);
            QTimer::singleShot(10000,this,[=](){
                delete ttp;//需要销毁才能在界面中重新绘制，不然会死机
                Two_Transform(2);
            });

        }

    });

}

myAlgTitleDialog::~myAlgTitleDialog()
{
    delete ui;
}
void myAlgTitleDialog::creationcoin2(int n)
{
    //mycoin *coin=new mycoin(":/res/Coin0001.png");
    //qDebug()<<coin->width()<<" "<<coin->height();//查看控件的大小
    //画出金币
    int mid=this->width()/2;
    int k=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<(2*i-1);j++)
        {
            mycoin*coin=new mycoin(":/res/Coin0001.png");
            coin->setParent(this);
            coin->posx=i;
            coin->posy=j+1;
            coin->move(mid-k+j*50,150+i*50);
            coin->graphposx=mid-k+j*50;
            coin->graphposy=150+i*50;
            coin->show();
        }
        k+=50;
    }
}
void myAlgTitleDialog:: deletecoin2()
{

    while (this->children().count()>9) {//因为除了金币按钮，该界面还有九个按钮
        for(int i=0;i<this->children().count();i++)
        {
        if(this->children().at(i)->inherits("mycoin"))//判断控件的类型
        {
             delete this->children().at(i);
        }
        }

    }
}
void myAlgTitleDialog:: Odd_Transform(int n)
{
    int btncount=this->children().count();//输出该窗体的所有控件
        int starmoveset=n/2;//计算开始移动的行数
        qDebug()<<starmoveset;//查看开始移动的行数
        int movecount=0;
        QSound *banksound=new QSound(":/souds/sound/coin2.wav");//播放移动的背景音乐
        banksound->play();
        QTimer::singleShot(3000,this,[=](){//3秒后关闭
            banksound->stop();
        });
        for(int i=0;i<btncount;i++)//遍历该窗体的所有控件
        {
             if(this->children().at(i)->inherits("mycoin"))//判断控件的类型
             {
             mycoin *bt=(mycoin *)(this->children().at(i));            
             if(bt->posx>starmoveset)
             {
                 movecount=bt->posx-starmoveset-1;
                 if(bt->posy<=movecount)//移动右边
                 {              
                     bt->movesite(bt->graphposx+movecount*50,bt->graphposy-movecount*100);
                     CreatMoveCoin(bt->graphposx,bt->graphposy);//把原先位置的金币的颜色变成灰色
                 }
                 if(bt->posy>=(2*bt->posx-movecount))//移动左边
                 {
                     bt->movesite(bt->graphposx-movecount*50,bt->graphposy-movecount*100);
                     CreatMoveCoin(bt->graphposx,bt->graphposy);//把原先位置的金币的颜色变成灰色
                 }

             }
          }
        }
}
void myAlgTitleDialog::Even_Transform(int n)
{
    int btncount=this->children().count();//输出该窗体的所有控件
    int starmoveset=n/2;//第几行开会时移动金币
    qDebug()<<starmoveset;//显示
    int movecount=1;//移动金币的数量
    QSound *banksound1=new QSound(":/souds/sound/coin2.wav");//播放移动的背景音乐
    banksound1->play();
    QTimer::singleShot(3000,this,[=](){//两秒后关闭
        banksound1->stop();
    });
    for(int i=0;i<btncount;i++)//遍历该窗体的所有控件
    {
         if(this->children().at(i)->inherits("mycoin"))//判断控件的类型
         {
         mycoin *bt=(mycoin *)(this->children().at(i));
         //qDebug()<<bt->posx<<" "<<bt->posy;
         if(bt->posx>starmoveset)
         {
             movecount=bt->posx-starmoveset;//更新移动的数量
             if(bt->posy<=movecount)//移动左边
             {
                 ;
                 bt->movesite(bt->graphposx+n*50,bt->graphposy-(2*(bt->posx-starmoveset)-1)*50);
                 //注意y轴上的偏移量，根据规律就，y轴每行是以1，3，5...*50的倍数开始偏移
                 //是一个等差数列
                 CreatMoveCoin(bt->graphposx,bt->graphposy);//把原先位置的金币的颜色变成灰色
             }
             if(bt->posy>(2*bt->posx-movecount))//移动右边
             {
                 bt->movesite(bt->graphposx-n*50,bt->graphposy-(2*(bt->posx-starmoveset)-1)*50);
                 CreatMoveCoin(bt->graphposx,bt->graphposy);//把原先位置的金币的颜色变成灰色
             }

         }
      }
    }
    //时隔4秒把当中的所有金币给删除
    QTimer::singleShot(3000,this,[=](){
        deletecoin2();//删除所有金币
    });
   //重新画出金币
   QTimer::singleShot(5000,this,[=](){
       creationcoin2(n);
   });
   QTimer::singleShot(6000,this,[=](){
       //第二种移动的方法
       QSound *banksound2=new QSound(":/souds/sound/coin2.wav");//播放移动的背景音乐
       banksound2->play();
       QTimer::singleShot(3000,this,[=](){//3秒后关闭
           banksound2->stop();
       });
       int btncount=this->children().count();//输出该窗体的所有控件
       int starmoveset=n/2;//第几行开会时移动金币
       qDebug()<<starmoveset;//显示
       int movecount=1;//移动金币的数量
       for(int i=0;i<btncount;i++)//遍历该窗体的所有控件
       {
            if(this->children().at(i)->inherits("mycoin"))//判断控件的类型
            {
            mycoin *bt=(mycoin *)(this->children().at(i));
            //qDebug()<<bt->posx<<" "<<bt->posy;
            if(bt->posx>starmoveset)
            {
                movecount=bt->posx-starmoveset;//更新移动的数量
                if(bt->posy>(2*bt->posx-movecount-1))//移动右边
                {
                    bt->movesite(bt->graphposx-n*50,bt->graphposy-(2*(bt->posx-starmoveset)-1)*50);
                    CreatMoveCoin(bt->graphposx,bt->graphposy);//把原先位置的金币的颜色变成灰色
                }
                if(bt->posy<=movecount-1)//移动左边
                {
                    bt->movesite(bt->graphposx+n*50,bt->graphposy-(2*(bt->posx-starmoveset)-1)*50);
                    //注意y轴上的偏移量，根据规律就，y轴每行是以1，3，5...*50的倍数开始偏移
                    //是一个等差数列
                    CreatMoveCoin(bt->graphposx,bt->graphposy);//把原先位置的金币的颜色变成灰色
                }
            }
         }
       }
   });
}
void myAlgTitleDialog::Two_Transform(int n)
{
    int coincount=this->children().count();
    for(int i=0;i<coincount;i++)
    {
        if(this->children().at(i)->inherits("mycoin"))
        {
            mycoin *bt=(mycoin *)(this->children().at(i));
            if((bt->posx==2)&&(bt->posy==1))
            {
                QSound *banksound=new QSound(":/souds/sound/ConFlipSound.wav");
                banksound->play();
                bt->movesite(bt->graphposx+100,bt->graphposy-50);
                CreatMoveCoin(bt->graphposx,bt->graphposy);//把原先位置的金币的颜色变成灰色
            }
        }
    }
    QTimer::singleShot(3000,this,[=](){//3秒后删除金币
       deletecoin2();
    });
    QTimer::singleShot(4000,this,[=](){//第4秒画出金币
        creationcoin2(n);
    });
    QTimer::singleShot(6000,this,[=](){//第6秒进行第二次变换
        int coincount=this->children().count();
        for(int i=0;i<coincount;i++)
        {
            if(this->children().at(i)->inherits("mycoin"))
            {
                mycoin *bt=(mycoin *)(this->children().at(i));
                if((bt->posx==2)&&(bt->posy==3))
                {
                    QSound *banksound=new QSound(":/souds/sound/ConFlipSound.wav");
                    banksound->play();
                    bt->movesite(bt->graphposx-100,bt->graphposy-50);
                    CreatMoveCoin(bt->graphposx,bt->graphposy);//把原先位置的金币的颜色变成灰色
                }
            }
        }
    });
    QTimer::singleShot(9000,this,[=](){//第9秒删除金币
        deletecoin2();
    });
    QTimer::singleShot(10000,this,[=](){//第10秒画出金币
        creationcoin2(n);
    });
    QTimer::singleShot(12000,this,[=](){//第12秒金币金币变换

        int coincount=this->children().count();
        for(int i=0;i<coincount;i++)//访问所有控件
        {
            //判断是否为自己定义的控件
            if(this->children().at(i)->inherits("mycoin"))
            {
                mycoin *bt=(mycoin *)(this->children().at(i));
                if((bt->posx==2)&&(bt->posy==2))
                {
                    QSound *banksound=new QSound(":/souds/sound/ConFlipSound.wav");
                    banksound->play();
                    bt->movesite(bt->graphposx,bt->graphposy+50);
                    CreatMoveCoin(bt->graphposx,bt->graphposy);//把原先位置的金币的颜色变成灰色
                }
            }
        }
    });
}
void myAlgTitleDialog::CreatMoveCoin(int x, int y)
{
    mycoin*coin=new mycoin(":/res/Coin0008.png");
    coin->setParent(this);
    coin->posx=x;
    coin->posy=y;
    coin->move(x,y);
    coin->graphposx=x;
    coin->graphposy=y;
    coin->show();
}
void myAlgTitleDialog::paintEvent(QPaintEvent *)//绘制背景图
{
    //设置背景
        QPainter painter(this);
        QPixmap pix;
        pix.load(":/res/演示背景3.PNG");
        painter.drawPixmap(0,200,this->width(),this->height(),pix);
        //加载标题
        pix.load(":/res/演示标题2.PNG");
        painter.drawPixmap(0,0,this->width(),200,pix);
}
void myAlgTitleDialog::SceneConfig()
{
    ui->labCoinNum->setVisible(false);//设置为不可见
    ui->labSuqNum->setVisible(false);
    this->setGeometry(QRect(770,200,1000,800));//设置窗体的大小
    this->setWindowTitle("斜线数目的输入以及演示");
    this->setWindowIcon(QPixmap(":/res/演示.png"));//设置图标
    this->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowCloseButtonHint);//去掉问好

    ui->label->setStyleSheet("font-size:55px;color:black");//样式表改变字体
    ui->pBtnStart->setText("开始计算");
    QPixmap pixmap(":/res/播放选中.png");
    QPixmap fitpixmap = pixmap.scaled(30, 30, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pBtnStart->setIcon(QIcon(fitpixmap));
    ui->pBtnStart->setIconSize(QSize(30, 30));
    ui->pBtnStart->setFlat(true);//边框是否突起
    ui->pBtnStart->setStyleSheet("border: 0px"); //消除边框
//    ui->pBtnStart->setStyleSheet("QPushButton{background-image: url(:/res/playone.png);}"
//                                 "QPushButton:hover{background-image: url(:/res/playone.png);}"
//                                 "QPushButton:pressed{background-image: url(:/res/面性停止播放.png);}");
    //hover是悬浮时的背景，pressed是按下的背景，没有就是正常情况
    ui->lEdtInputN->setStyleSheet("border: 0px");
    QPixmap pixmap2(":/res/返回.png");
    QPixmap fitpixmap2 = pixmap2.scaled(60, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton->setIcon(QIcon(fitpixmap2));
    ui->pushButton->setIconSize(QSize(60, 40));
    ui->pushButton->setFlat(true);
    ui->pushButton->setStyleSheet("border: 0px"); //消除边框
}
