﻿#ifndef MYPUSHBOTTON_H
#define MYPUSHBOTTON_H
#include <QPushButton>
class MyPushBotton : public QPushButton
{
    Q_OBJECT
public:
    //explicit MyPushBotton(QWidget *parent = nullptr);
    MyPushBotton(QString normalImg,QString pressImg="");
    //成员属性
    QString normalImgPath;
    QString pressImgPath;
    void  zoom1();
    void zoom2();
    //重写按钮按下与释放事件
    void mousePressEvent(QMouseEvent *e);
    void mouseReleaseEvent(QMouseEvent *e);
signals:
};
#endif // MYPUSHBOTTON_H
