﻿#include "enrolldialog.h"
#include "ui_enrolldialog.h"
#include<QMessageBox>
#include<QSqlQuery>
#include<QSqlError>
#include<string>
#pragma execution_character_set("utf-8")
#include<QDebug>
#include<QTimer>
#include<QPainter>
#include"mypushbotton.h"
#include<QDateTime>
#include<QFileDialog>
#include<QDateTime>
#include"logindialog.h"
QString filename="";//设计全局变量，供函数使用
enrollDialog::enrollDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::enrollDialog)
{
    ui->setupUi(this);
    enroConfig();//配置信息
    connect(ui->pBtnEnroll,&QPushButton::clicked,this,[=](){//点击注册按钮
        QString count=ui->linEdtCount->text();
        QString pwd=ui->linEdtPwd->text();
        QString name=ui->linEdtName->text();
        QString call=ui->linEdtCall->text();
        //确保信息输入完整
        if(count.isEmpty()||pwd.isEmpty()||name.isEmpty()||call.isEmpty()||filename=="")
        {
            QMessageBox::warning(this,"提示","请把所有的信息输入完成！");
             return;
        }
        QString sex;
        if(ui->rdBtnMan->isChecked())
            sex="男";
        else if(ui->rdBtnWoman->isChecked())
            sex="女";
        QDateTime curDateTime=QDateTime::currentDateTime();
        QString time=curDateTime.toString("yyMMddhhmmss");//获取图片命名的时间
        QFileInfo fileInfo = QFileInfo(filename);//获取图片后缀名
        QString houzhui=fileInfo.suffix();
        //拼凑图片的路径，账号+时间+原图片后缀
        QString imgpath=QString("./userimg/%1%2.%3").arg(ui->linEdtCount->text()).arg(time).arg(houzhui);
        QFile::copy(filename,imgpath);//把图片复制到文件的相对路径之下
        QString str=QString("insert into 用户表(账号,密码,用户名,电话,性别,头像)"
                            " values ('%1','%2','%3','%4','%5','%6')").arg(count).arg(pwd)
                .arg(name).arg(call).arg(sex).arg(imgpath);
        qDebug()<<str;
        QSqlQuery query;
        if(query.exec(str))//执行成功
        {
           QMessageBox::about(this,"提示","注册成功！");
           //发出返回信号
//           QTimer::singleShot(30,this,[=](){
//              emit bancklogsence();
//           });
           loginDialog *log=new loginDialog();
           log->show();
           this->deleteLater();//稍后销毁该界面
        }
        else//执行失败
        {
            //获取错误信息并提示错误信息
            qDebug()<<query.lastError().text();
            QMessageBox::about(this,"提示",query.lastError().text());
            return;
        }
    });
    //创建一个自定义的返回按钮
    MyPushBotton *backBtn=new MyPushBotton(":/res/BackButton.png",":/res/BackButtonSelected.png");
    backBtn->setParent(this);
    backBtn->move(this->width()-backBtn->width()-20,this->height()-backBtn->height()-20);//移动按钮的位置
    connect(backBtn,&MyPushBotton::clicked,[=](){//点击的功能
        QTimer::singleShot(30,this,[=](){
            emit bancklogsence();//发出返回信号
        });
    });
    connect(ui->pushButton,&QPushButton::clicked,this,[=](){//监听图片选择按钮
        if(ui->linEdtCount->text().isEmpty())
        {
            QMessageBox::warning(this,"提示","请先输入账号！");//确保有账号，因为对头像图片命名要用到
             return;
        }
        QSqlQuery query;
        QString count1=ui->linEdtCount->text();//获取输入的账号
        QString str=QString("select *from 用户表 where 账号='%1'").arg(count1);
        query.exec(str);
        if(!query.next())//账号在数据库中不存在，可以注册。开始选择头像
        {
           filename=QFileDialog::getOpenFileName(this,tr("选择图像"),"",tr("Images (*.png *.bmp *.jpg)"));
           if(filename.isEmpty())
               return;
           else
           {
              QImage img;
               if(!(img.load(filename))) //加载图像
              {
                  QMessageBox::information(this, tr("打开图像失败"),tr("打开图像失败!"));
                  return;
              }
              ui->label_14->setPixmap(QPixmap::fromImage(img.scaled(ui->label_14->size())));//显示图片头像
              QPixmap pix1(filename);
              pix1=pix1.scaled(ui->label_14->width(),ui->label_14->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
              ui->label_14->setPixmap(pix1);
              ui->label_14->setVisible(true);
           }
        }
        else
        {
            QMessageBox::warning(this,"提示","该账号已经存在，请重新输入！");//注册的账号已经存在
             return;
        }
    });
}
enrollDialog::~enrollDialog()
{
    delete ui;
}
void enrollDialog::paintEvent(QPaintEvent *)//绘制背景图
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/res/注册背景.jpeg");
    painter.drawPixmap(0,0,this->width(),this->height(),pix);
}
void enrollDialog::enroConfig()
{
    this->setWindowTitle(QString("注册"));//设置title
    this->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowCloseButtonHint);//去掉问好
    this->setWindowIcon(QPixmap(":/res/page.png"));//设置图标
    ui->label_14->setVisible(false);
    QPixmap pix(":/res/信息.png");//配置标题
    pix=pix.scaled(ui->label_8->width(),ui->label_8->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_8->setPixmap(pix);
    pix.load(":/res/账号.png");//账号图标
    pix=pix.scaled(ui->label_9->width(),ui->label_9->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_9->setPixmap(pix);
    pix.load(":/res/密码.png");//密码图标
    pix=pix.scaled(ui->label_10->width(),ui->label_10->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_10->setPixmap(pix);
    pix.load(":/res/昵称.png");//昵称图标
    pix=pix.scaled(ui->label_11->width(),ui->label_11->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_11->setPixmap(pix);
    pix.load(":/res/电话.png");//电话图标
    pix=pix.scaled(ui->label_12->width(),ui->label_12->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_12->setPixmap(pix);
    pix.load(":/res/性别.png");//性别图标
    pix=pix.scaled(ui->label_13->width(),ui->label_13->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_13->setPixmap(pix);
    pix.load(":/res/确认.png");//确认注册的图标
    pix = pix.scaled(120,160, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pBtnEnroll->setIcon(QIcon(pix));//给注册添加图标
    ui->pBtnEnroll->setIconSize(QSize(ui->pBtnEnroll->width(), ui->pBtnEnroll->height()));
    ui->pBtnEnroll->setFlat(true);
    ui->pBtnEnroll->setStyleSheet("border: 0px"); //消除边框
    pix.load(":/res/男店员.png");//男性别图标
    pix=pix.scaled(ui->rdBtnMan->width(),ui->rdBtnMan->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->rdBtnMan->setIcon(pix);
    ui->rdBtnMan->setIconSize(QSize(80,120));
    pix.load(":/res/女店员.png");//男性别图标
    pix=pix.scaled(ui->rdBtnWoman->width(),ui->rdBtnWoman->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->rdBtnWoman->setIcon(pix);
    ui->rdBtnWoman->setIconSize(QSize(80,120));
    pix.load(":/res/照片.png");//头像图标
    pix=pix.scaled(ui->label_15->width(),ui->label_15->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_15->setPixmap(pix);
    pix.load(":/res/添加照片.png");//添加照片图标
    pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pushButton->setIcon(QIcon(pix));
    ui->pushButton->setIconSize(QSize(40, 40));
    ui->pushButton->setFlat(true);//边框是否突起
}


