﻿#ifndef ENROLLDIALOG_H
#define ENROLLDIALOG_H
#include <QDialog>
extern QString filename;
namespace Ui {
class enrollDialog;
}

class enrollDialog : public QDialog
{
    Q_OBJECT

public:
    explicit enrollDialog(QWidget *parent = nullptr);
    ~enrollDialog();
    void paintEvent(QPaintEvent *);//绘制背景图
    void enroConfig();//配置函数

private:
    Ui::enrollDialog *ui;
signals:
    void bancklogsence();//返回登录的界面
private slots:
};
#endif // ENROLLDIALOG_H



