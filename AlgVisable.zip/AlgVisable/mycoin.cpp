﻿#include "mycoin.h"
#include<QDebug>
#pragma execution_character_set("utf-8")
#include<QPropertyAnimation>

//mycoin::mycoin(QWidget *parent) : QWidget(parent)
//{

//}
mycoin::mycoin(QString btnImg)
{
    QPixmap pix;
    bool ret=pix.load(btnImg);//加载图片
    if(!ret)
    {
        QString str=QString("图片%1加载失败").arg(btnImg);
        qDebug()<<str;
        return;
    }
    this->setFixedSize(pix.width(),pix.height());
    this->setStyleSheet("QPushButton{border:0px}");
    this->setIcon(pix);
    this->setIconSize(QSize(pix.width(),pix.height()));
}
void mycoin::movesite(int newx, int newy)
{
    //创建动态对象
    QPropertyAnimation *animation=new QPropertyAnimation(this,"geometry");
    //创建动画时间间隔
    animation->setDuration(2000);
    //起始位置
    animation->setStartValue(QRect(this->x(),this->y(),this->width(),this->height()));
    //结束位置
    animation->setEndValue(QRect(newx,newy,this->width(),this->height()));
    //设置弹跳曲线
    animation->setEasingCurve(QEasingCurve::OutBounce);
    //执行动画
    animation->start();
}
