﻿#include "logindialog.h"
#include "ui_logindialog.h"
#include<QMessageBox>
#include<QSqlQuery>
#include<QDebug>
#include"enrolldialog.h"
#include<QPainter>
#include"mainwindow.h"
#pragma execution_character_set("utf-8")
QString glbaccount="";//声明一个全局变量
loginDialog::loginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::loginDialog)
{
    ui->setupUi(this);
    LogConfig();
    //监听登录按钮
    connect(ui->pBtnLog,&QPushButton::clicked,this,[=](){
        //获取输入的账号和密码
        QString count=ui->lineEdit->text();
        QString pwd=ui->lineEdit_pwd->text();
        //提醒账号密码输入不能为空
        if(count.isEmpty()==true)
        {
            QMessageBox::warning(this,"提示","账号不能为空！");
            return;
        }
        if(pwd.isEmpty()==true)
        {
            QMessageBox::warning(this,"提示","密码不能为空！");
            return;
        }
        //数据库查询该账号的密码
        QSqlQuery query;
        QString count1=ui->lineEdit->text();
        QString str=QString("select 密码 from 用户表 where 账号='%1'").arg(count1);
        query.exec(str);
       //如果账号存在，就看密码是否匹配
        if(!query.next())//账号不存在
        {
            QMessageBox::warning(this,"提示","该账户不存在");
            return;
        }
        else
        {
            QString tempwd=query.value(0).toString();//数据库中的密码
            QString inputpwd=ui->lineEdit_pwd->text();//输入的密码
            if(tempwd.compare(inputpwd)!=0)//如果不相等
            {
            QMessageBox::warning(this,"提示","密码错误");
            return;
            }
        }
        glbaccount=ui->lineEdit->text();
        //QDialog::accept();//接受
        MainWindow *main=new MainWindow();
        main->show();
        this->close();
        //emit sendData(ui->lineEdit->text());//把账号发送到主页面
    });
    enrollDialog *enroll=new enrollDialog();
    //监听注册的返回的信号
    connect(enroll,&enrollDialog::bancklogsence,this,[=](){
        enroll->hide();
        this->show();
    });
    //监听注册按钮
    connect(ui->pBtnRegst,&QPushButton::clicked,this,[=](){
         this->hide();
        enroll->show();
    });
}
loginDialog::~loginDialog()
{
    delete ui;
}
void loginDialog::paintEvent(QPaintEvent *)
{
        //设置背景
        QPainter painter(this);
        QPixmap pix;
        pix.load(":/res/登录背景2.jpeg");
        painter.drawPixmap(0,0,this->width(),this->height(),pix);
}
void loginDialog::LogConfig()
{
    this->setWindowTitle(QString("登录"));//设置title
    this->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowCloseButtonHint);//去掉问好
    this->setWindowIcon(QPixmap(":/res/loading.png"));//设置图标
    QPixmap iconaaa(":/res/算法模型编排工具.png");
    iconaaa = iconaaa.scaled(ui->label_5->width(),ui->label_5->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_5->setPixmap(iconaaa);//给标题添加图标
    iconaaa.load(":/res/账号.png");
    iconaaa=iconaaa.scaled(ui->label_4->width(),ui->label_4->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_4->setPixmap(iconaaa);
    iconaaa.load(":/res/密码.png");//给账号添加图标
    iconaaa=iconaaa.scaled(ui->label_3->width(),ui->label_3->height(),Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label_3->setPixmap(iconaaa);//给密码添加图标
    QPixmap pixmap(":/res/17-登录.png");
    QPixmap fitpixmap = pixmap.scaled(100,100, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pBtnLog->setIcon(QIcon(fitpixmap));//给登录添加图标
    ui->pBtnLog->setIconSize(QSize(ui->pBtnLog->width(), ui->pBtnLog->height()));
    ui->pBtnLog->setFlat(true);
    ui->pBtnLog->setStyleSheet("border: 0px"); //消除边框
    pixmap.load(":/res/注册.png");
    fitpixmap = pixmap.scaled(100,100, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->pBtnRegst->setIcon(QIcon(fitpixmap));//给注册添加图标
    ui->pBtnRegst->setIconSize(QSize(ui->pBtnLog->width(), ui->pBtnLog->height()));
    ui->pBtnRegst->setFlat(true);
    ui->pBtnRegst->setStyleSheet("border: 0px"); //消除边框
}

