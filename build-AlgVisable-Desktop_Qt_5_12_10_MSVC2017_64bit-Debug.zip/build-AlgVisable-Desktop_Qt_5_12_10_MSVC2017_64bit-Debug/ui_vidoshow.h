/********************************************************************************
** Form generated from reading UI file 'vidoshow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIDOSHOW_H
#define UI_VIDOSHOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_vidoshow
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QWidget *vidoshow)
    {
        if (vidoshow->objectName().isEmpty())
            vidoshow->setObjectName(QString::fromUtf8("vidoshow"));
        vidoshow->resize(1097, 989);
        label = new QLabel(vidoshow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 90, 981, 711));
        pushButton = new QPushButton(vidoshow);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(320, 830, 131, 61));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        pushButton->setFont(font);
        pushButton_2 = new QPushButton(vidoshow);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(520, 830, 131, 61));
        pushButton_2->setFont(font);
        pushButton_3 = new QPushButton(vidoshow);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(730, 830, 131, 61));
        pushButton_3->setFont(font);

        retranslateUi(vidoshow);

        QMetaObject::connectSlotsByName(vidoshow);
    } // setupUi

    void retranslateUi(QWidget *vidoshow)
    {
        vidoshow->setWindowTitle(QApplication::translate("vidoshow", "Form", nullptr));
        label->setText(QApplication::translate("vidoshow", "TextLabel", nullptr));
        pushButton->setText(QApplication::translate("vidoshow", "\346\232\202\346\233\277", nullptr));
        pushButton_2->setText(QApplication::translate("vidoshow", "\346\222\255\346\224\276", nullptr));
        pushButton_3->setText(QApplication::translate("vidoshow", "\350\277\224\345\233\236", nullptr));
    } // retranslateUi

};

namespace Ui {
    class vidoshow: public Ui_vidoshow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIDOSHOW_H
