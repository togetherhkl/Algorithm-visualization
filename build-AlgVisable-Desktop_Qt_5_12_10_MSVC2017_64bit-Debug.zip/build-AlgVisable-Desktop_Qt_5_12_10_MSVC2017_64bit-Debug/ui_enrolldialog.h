/********************************************************************************
** Form generated from reading UI file 'enrolldialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENROLLDIALOG_H
#define UI_ENROLLDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_enrollDialog
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QPushButton *pBtnEnroll;
    QLineEdit *linEdtCount;
    QLineEdit *linEdtPwd;
    QLineEdit *linEdtName;
    QLineEdit *linEdtCall;
    QRadioButton *rdBtnMan;
    QRadioButton *rdBtnWoman;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QPushButton *pushButton;
    QLabel *label_15;
    QButtonGroup *buttonGroup;

    void setupUi(QDialog *enrollDialog)
    {
        if (enrollDialog->objectName().isEmpty())
            enrollDialog->setObjectName(QString::fromUtf8("enrollDialog"));
        enrollDialog->resize(772, 866);
        label = new QLabel(enrollDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(250, 120, 251, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Agency FB"));
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label_2 = new QLabel(enrollDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(150, 270, 81, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(10);
        font1.setBold(false);
        font1.setWeight(50);
        label_2->setFont(font1);
        label_3 = new QLabel(enrollDialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(150, 330, 81, 31));
        label_3->setFont(font1);
        label_4 = new QLabel(enrollDialog);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(150, 410, 81, 31));
        label_4->setFont(font1);
        label_5 = new QLabel(enrollDialog);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(150, 480, 81, 31));
        label_5->setFont(font1);
        label_6 = new QLabel(enrollDialog);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(150, 550, 71, 31));
        label_6->setFont(font1);
        label_7 = new QLabel(enrollDialog);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(150, 640, 111, 31));
        label_7->setFont(font1);
        pBtnEnroll = new QPushButton(enrollDialog);
        pBtnEnroll->setObjectName(QString::fromUtf8("pBtnEnroll"));
        pBtnEnroll->setGeometry(QRect(140, 770, 181, 71));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Agency FB"));
        font2.setPointSize(16);
        font2.setBold(true);
        font2.setWeight(75);
        pBtnEnroll->setFont(font2);
        linEdtCount = new QLineEdit(enrollDialog);
        linEdtCount->setObjectName(QString::fromUtf8("linEdtCount"));
        linEdtCount->setGeometry(QRect(250, 260, 231, 41));
        linEdtPwd = new QLineEdit(enrollDialog);
        linEdtPwd->setObjectName(QString::fromUtf8("linEdtPwd"));
        linEdtPwd->setGeometry(QRect(250, 330, 231, 41));
        linEdtName = new QLineEdit(enrollDialog);
        linEdtName->setObjectName(QString::fromUtf8("linEdtName"));
        linEdtName->setGeometry(QRect(250, 400, 231, 41));
        linEdtCall = new QLineEdit(enrollDialog);
        linEdtCall->setObjectName(QString::fromUtf8("linEdtCall"));
        linEdtCall->setGeometry(QRect(250, 470, 231, 41));
        rdBtnMan = new QRadioButton(enrollDialog);
        buttonGroup = new QButtonGroup(enrollDialog);
        buttonGroup->setObjectName(QString::fromUtf8("buttonGroup"));
        buttonGroup->addButton(rdBtnMan);
        rdBtnMan->setObjectName(QString::fromUtf8("rdBtnMan"));
        rdBtnMan->setGeometry(QRect(260, 540, 151, 51));
        rdBtnMan->setFont(font1);
        rdBtnWoman = new QRadioButton(enrollDialog);
        buttonGroup->addButton(rdBtnWoman);
        rdBtnWoman->setObjectName(QString::fromUtf8("rdBtnWoman"));
        rdBtnWoman->setGeometry(QRect(460, 540, 171, 51));
        rdBtnWoman->setFont(font1);
        label_8 = new QLabel(enrollDialog);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(160, 120, 71, 61));
        label_9 = new QLabel(enrollDialog);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(80, 260, 51, 41));
        label_10 = new QLabel(enrollDialog);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(80, 320, 51, 41));
        label_11 = new QLabel(enrollDialog);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(80, 400, 51, 41));
        label_12 = new QLabel(enrollDialog);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(80, 470, 51, 41));
        label_13 = new QLabel(enrollDialog);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(80, 540, 51, 41));
        label_14 = new QLabel(enrollDialog);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(410, 630, 131, 141));
        pushButton = new QPushButton(enrollDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(250, 630, 161, 51));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font3.setPointSize(10);
        font3.setBold(true);
        font3.setWeight(75);
        pushButton->setFont(font3);
        label_15 = new QLabel(enrollDialog);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(80, 630, 51, 41));
        QWidget::setTabOrder(rdBtnWoman, linEdtCount);
        QWidget::setTabOrder(linEdtCount, linEdtPwd);
        QWidget::setTabOrder(linEdtPwd, linEdtName);
        QWidget::setTabOrder(linEdtName, linEdtCall);
        QWidget::setTabOrder(linEdtCall, rdBtnMan);
        QWidget::setTabOrder(rdBtnMan, pBtnEnroll);

        retranslateUi(enrollDialog);

        QMetaObject::connectSlotsByName(enrollDialog);
    } // setupUi

    void retranslateUi(QDialog *enrollDialog)
    {
        enrollDialog->setWindowTitle(QApplication::translate("enrollDialog", "Dialog", nullptr));
        label->setText(QApplication::translate("enrollDialog", "\344\277\241\346\201\257\346\263\250\345\206\214", nullptr));
        label_2->setText(QApplication::translate("enrollDialog", "\350\264\246\345\217\267", nullptr));
        label_3->setText(QApplication::translate("enrollDialog", "\345\257\206\347\240\201", nullptr));
        label_4->setText(QApplication::translate("enrollDialog", "\346\230\265\347\247\260", nullptr));
        label_5->setText(QApplication::translate("enrollDialog", "\347\224\265\350\257\235", nullptr));
        label_6->setText(QApplication::translate("enrollDialog", "\346\200\247\345\210\253", nullptr));
        label_7->setText(QApplication::translate("enrollDialog", "\345\244\264\345\203\217\351\200\211\346\213\251", nullptr));
        pBtnEnroll->setText(QApplication::translate("enrollDialog", "\347\241\256\350\256\244\346\263\250\345\206\214", nullptr));
        rdBtnMan->setText(QApplication::translate("enrollDialog", "\347\224\267", nullptr));
        rdBtnWoman->setText(QApplication::translate("enrollDialog", "\345\245\263", nullptr));
        label_8->setText(QApplication::translate("enrollDialog", "TextLabel", nullptr));
        label_9->setText(QApplication::translate("enrollDialog", "TextLabel", nullptr));
        label_10->setText(QApplication::translate("enrollDialog", "TextLabel", nullptr));
        label_11->setText(QApplication::translate("enrollDialog", "TextLabel", nullptr));
        label_12->setText(QApplication::translate("enrollDialog", "TextLabel", nullptr));
        label_13->setText(QApplication::translate("enrollDialog", "TextLabel", nullptr));
        label_14->setText(QApplication::translate("enrollDialog", "TextLabel", nullptr));
        pushButton->setText(QApplication::translate("enrollDialog", "\347\202\271\345\207\273\351\200\211\346\213\251", nullptr));
        label_15->setText(QApplication::translate("enrollDialog", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class enrollDialog: public Ui_enrollDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENROLLDIALOG_H
