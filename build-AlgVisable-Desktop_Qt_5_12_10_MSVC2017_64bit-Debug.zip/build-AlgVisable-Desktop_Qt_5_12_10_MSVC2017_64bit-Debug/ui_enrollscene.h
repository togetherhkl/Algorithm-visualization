/********************************************************************************
** Form generated from reading UI file 'enrollscene.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENROLLSCENE_H
#define UI_ENROLLSCENE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_enrollscene
{
public:
    QLabel *labelTitle;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QLabel *label_5;
    QPushButton *pushButton;

    void setupUi(QWidget *enrollscene)
    {
        if (enrollscene->objectName().isEmpty())
            enrollscene->setObjectName(QString::fromUtf8("enrollscene"));
        enrollscene->resize(494, 435);
        labelTitle = new QLabel(enrollscene);
        labelTitle->setObjectName(QString::fromUtf8("labelTitle"));
        labelTitle->setGeometry(QRect(170, 10, 191, 61));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        labelTitle->setFont(font);
        label = new QLabel(enrollscene);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 100, 41, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Agency FB"));
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_2 = new QLabel(enrollscene);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 140, 41, 31));
        label_2->setFont(font1);
        label_3 = new QLabel(enrollscene);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(40, 180, 41, 31));
        label_3->setFont(font1);
        label_4 = new QLabel(enrollscene);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(40, 220, 41, 31));
        label_4->setFont(font1);
        lineEdit = new QLineEdit(enrollscene);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(90, 100, 161, 31));
        lineEdit_2 = new QLineEdit(enrollscene);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(90, 140, 161, 31));
        lineEdit_3 = new QLineEdit(enrollscene);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(90, 180, 161, 31));
        radioButton = new QRadioButton(enrollscene);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(100, 230, 91, 18));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Agency FB"));
        font2.setPointSize(16);
        font2.setBold(true);
        font2.setWeight(75);
        radioButton->setFont(font2);
        radioButton_2 = new QRadioButton(enrollscene);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(170, 230, 91, 18));
        radioButton_2->setFont(font2);
        label_5 = new QLabel(enrollscene);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(40, 260, 101, 31));
        label_5->setFont(font1);
        pushButton = new QPushButton(enrollscene);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(40, 320, 81, 41));
        pushButton->setFont(font2);

        retranslateUi(enrollscene);

        QMetaObject::connectSlotsByName(enrollscene);
    } // setupUi

    void retranslateUi(QWidget *enrollscene)
    {
        enrollscene->setWindowTitle(QApplication::translate("enrollscene", "Form", nullptr));
        labelTitle->setText(QApplication::translate("enrollscene", "\344\277\241\346\201\257\346\263\250\345\206\214", nullptr));
        label->setText(QApplication::translate("enrollscene", "\350\264\246\345\217\267", nullptr));
        label_2->setText(QApplication::translate("enrollscene", "\345\257\206\347\240\201", nullptr));
        label_3->setText(QApplication::translate("enrollscene", "\346\230\265\347\247\260", nullptr));
        label_4->setText(QApplication::translate("enrollscene", "\346\200\247\345\210\253", nullptr));
        radioButton->setText(QApplication::translate("enrollscene", "\347\224\267", nullptr));
        radioButton_2->setText(QApplication::translate("enrollscene", "\345\245\263", nullptr));
        label_5->setText(QApplication::translate("enrollscene", "\345\244\264\345\203\217\351\200\211\346\213\251", nullptr));
        pushButton->setText(QApplication::translate("enrollscene", "\346\263\250\345\206\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class enrollscene: public Ui_enrollscene {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENROLLSCENE_H
