/********************************************************************************
** Form generated from reading UI file 'pictureshow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PICTURESHOW_H
#define UI_PICTURESHOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PictureShow
{
public:

    void setupUi(QWidget *PictureShow)
    {
        if (PictureShow->objectName().isEmpty())
            PictureShow->setObjectName(QString::fromUtf8("PictureShow"));
        PictureShow->resize(1060, 1021);

        retranslateUi(PictureShow);

        QMetaObject::connectSlotsByName(PictureShow);
    } // setupUi

    void retranslateUi(QWidget *PictureShow)
    {
        PictureShow->setWindowTitle(QApplication::translate("PictureShow", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PictureShow: public Ui_PictureShow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PICTURESHOW_H
