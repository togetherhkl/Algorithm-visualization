/********************************************************************************
** Form generated from reading UI file 'myalgtitledialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYALGTITLEDIALOG_H
#define UI_MYALGTITLEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_myAlgTitleDialog
{
public:
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lEdtInputN;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *labCoinNum;
    QLabel *labSuqNum;
    QPushButton *pBtnStart;
    QPushButton *pushButton;

    void setupUi(QDialog *myAlgTitleDialog)
    {
        if (myAlgTitleDialog->objectName().isEmpty())
            myAlgTitleDialog->setObjectName(QString::fromUtf8("myAlgTitleDialog"));
        myAlgTitleDialog->resize(1003, 1083);
        label = new QLabel(myAlgTitleDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 10, 821, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        font.setPointSize(26);
        font.setBold(false);
        font.setWeight(50);
        label->setFont(font);
        label_2 = new QLabel(myAlgTitleDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 90, 191, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(14);
        font1.setBold(false);
        font1.setWeight(50);
        label_2->setFont(font1);
        lEdtInputN = new QLineEdit(myAlgTitleDialog);
        lEdtInputN->setObjectName(QString::fromUtf8("lEdtInputN"));
        lEdtInputN->setGeometry(QRect(190, 90, 113, 41));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font2.setPointSize(10);
        font2.setBold(true);
        font2.setWeight(75);
        lEdtInputN->setFont(font2);
        label_3 = new QLabel(myAlgTitleDialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 150, 261, 41));
        label_3->setFont(font1);
        label_4 = new QLabel(myAlgTitleDialog);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(460, 150, 251, 41));
        label_4->setFont(font1);
        labCoinNum = new QLabel(myAlgTitleDialog);
        labCoinNum->setObjectName(QString::fromUtf8("labCoinNum"));
        labCoinNum->setGeometry(QRect(260, 150, 101, 41));
        labCoinNum->setFont(font1);
        labSuqNum = new QLabel(myAlgTitleDialog);
        labSuqNum->setObjectName(QString::fromUtf8("labSuqNum"));
        labSuqNum->setGeometry(QRect(680, 150, 101, 41));
        labSuqNum->setFont(font1);
        pBtnStart = new QPushButton(myAlgTitleDialog);
        pBtnStart->setObjectName(QString::fromUtf8("pBtnStart"));
        pBtnStart->setGeometry(QRect(330, 70, 141, 71));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font3.setPointSize(11);
        font3.setBold(true);
        font3.setWeight(75);
        pBtnStart->setFont(font3);
        pushButton = new QPushButton(myAlgTitleDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(830, 720, 171, 71));
        pushButton->setFont(font3);

        retranslateUi(myAlgTitleDialog);

        QMetaObject::connectSlotsByName(myAlgTitleDialog);
    } // setupUi

    void retranslateUi(QDialog *myAlgTitleDialog)
    {
        myAlgTitleDialog->setWindowTitle(QApplication::translate("myAlgTitleDialog", "Dialog", nullptr));
        label->setText(QApplication::translate("myAlgTitleDialog", "\347\256\227\346\263\225\350\260\234\351\242\23060\357\274\232\347\241\254\345\270\201\344\270\211\350\247\222\345\275\242\345\217\230\346\255\243\346\226\271\345\275\242", nullptr));
        label_2->setText(QApplication::translate("myAlgTitleDialog", "\350\257\267\350\276\223\345\205\245\347\233\264\347\272\277n\357\274\232", nullptr));
        label_3->setText(QApplication::translate("myAlgTitleDialog", "\346\234\200\345\260\221\347\247\273\345\212\250\351\207\221\345\270\201\346\225\260\347\233\256\357\274\232", nullptr));
        label_4->setText(QApplication::translate("myAlgTitleDialog", "\344\270\215\345\220\214\346\255\243\346\226\271\345\275\242\346\225\260\347\233\256\357\274\232", nullptr));
        labCoinNum->setText(QApplication::translate("myAlgTitleDialog", "num", nullptr));
        labSuqNum->setText(QApplication::translate("myAlgTitleDialog", "num", nullptr));
        pBtnStart->setText(QApplication::translate("myAlgTitleDialog", "\345\274\200\345\247\213\350\256\241\347\256\227", nullptr));
        pushButton->setText(QApplication::translate("myAlgTitleDialog", "\350\277\224\345\233\236", nullptr));
    } // retranslateUi

};

namespace Ui {
    class myAlgTitleDialog: public Ui_myAlgTitleDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYALGTITLEDIALOG_H
