/********************************************************************************
** Form generated from reading UI file 'logindialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINDIALOG_H
#define UI_LOGINDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_loginDialog
{
public:
    QWidget *widget;
    QLabel *labelTitle;
    QLabel *label_5;
    QWidget *widget_2;
    QLabel *label_count;
    QLineEdit *lineEdit;
    QLabel *label_pwd;
    QLineEdit *lineEdit_pwd;
    QPushButton *pBtnLog;
    QPushButton *pBtnRegst;
    QLabel *label_3;
    QLabel *label_4;

    void setupUi(QDialog *loginDialog)
    {
        if (loginDialog->objectName().isEmpty())
            loginDialog->setObjectName(QString::fromUtf8("loginDialog"));
        loginDialog->resize(718, 479);
        widget = new QWidget(loginDialog);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(160, 50, 391, 121));
        labelTitle = new QLabel(widget);
        labelTitle->setObjectName(QString::fromUtf8("labelTitle"));
        labelTitle->setGeometry(QRect(110, 20, 261, 81));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font.setPointSize(22);
        font.setBold(false);
        font.setWeight(50);
        labelTitle->setFont(font);
        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 30, 71, 71));
        widget_2 = new QWidget(loginDialog);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setGeometry(QRect(150, 170, 411, 261));
        label_count = new QLabel(widget_2);
        label_count->setObjectName(QString::fromUtf8("label_count"));
        label_count->setGeometry(QRect(80, 20, 61, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(10);
        font1.setBold(false);
        font1.setWeight(50);
        label_count->setFont(font1);
        lineEdit = new QLineEdit(widget_2);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(160, 30, 181, 31));
        label_pwd = new QLabel(widget_2);
        label_pwd->setObjectName(QString::fromUtf8("label_pwd"));
        label_pwd->setGeometry(QRect(80, 80, 71, 31));
        label_pwd->setFont(font1);
        lineEdit_pwd = new QLineEdit(widget_2);
        lineEdit_pwd->setObjectName(QString::fromUtf8("lineEdit_pwd"));
        lineEdit_pwd->setGeometry(QRect(160, 80, 181, 31));
        lineEdit_pwd->setEchoMode(QLineEdit::Password);
        pBtnLog = new QPushButton(widget_2);
        pBtnLog->setObjectName(QString::fromUtf8("pBtnLog"));
        pBtnLog->setGeometry(QRect(40, 140, 131, 41));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font2.setPointSize(10);
        pBtnLog->setFont(font2);
        pBtnRegst = new QPushButton(widget_2);
        pBtnRegst->setObjectName(QString::fromUtf8("pBtnRegst"));
        pBtnRegst->setGeometry(QRect(210, 140, 141, 41));
        pBtnRegst->setFont(font1);
        label_3 = new QLabel(widget_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 80, 51, 41));
        label_4 = new QLabel(widget_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 20, 51, 41));

        retranslateUi(loginDialog);

        QMetaObject::connectSlotsByName(loginDialog);
    } // setupUi

    void retranslateUi(QDialog *loginDialog)
    {
        loginDialog->setWindowTitle(QApplication::translate("loginDialog", "Dialog", nullptr));
        labelTitle->setText(QApplication::translate("loginDialog", "\347\256\227\346\263\225\345\217\257\350\247\206\345\214\226", nullptr));
        label_5->setText(QApplication::translate("loginDialog", "TextLabel", nullptr));
        label_count->setText(QApplication::translate("loginDialog", "\350\264\246\345\217\267", nullptr));
        label_pwd->setText(QApplication::translate("loginDialog", "\345\257\206\347\240\201", nullptr));
        pBtnLog->setText(QApplication::translate("loginDialog", "\347\231\273\345\275\225", nullptr));
        pBtnRegst->setText(QApplication::translate("loginDialog", "\346\263\250\345\206\214", nullptr));
        label_3->setText(QApplication::translate("loginDialog", "TextLabel", nullptr));
        label_4->setText(QApplication::translate("loginDialog", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class loginDialog: public Ui_loginDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINDIALOG_H
